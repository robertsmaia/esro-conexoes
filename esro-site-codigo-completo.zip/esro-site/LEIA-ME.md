# Site ESRO — código completo

## Como abrir
Extraia o ZIP e abra `dist/index.html` no navegador.
Para servir por HTTP, com Python instalado, execute na pasta extraída:

    python -m http.server 8000 --directory dist

Depois acesse http://localhost:8000.

## Arquivos
- dist/index.html: página completa, com HTML, CSS e JavaScript no mesmo arquivo.
- dist/assets/: imagens utilizadas pelo site.
- dist/catalogo-esro.pdf: catálogo original para visualização e download.
- .openai/hosting.json: identificação e configuração da hospedagem Sites.

O projeto é estático: não exige instalação de dependências nem compilação.
Para hospedar em outro serviço, publique o conteúdo da pasta dist.
As fontes do Google Fonts e os links para WhatsApp e Instagram precisam de internet.

## Observações
Esta cópia contém o código disponível no projeto local, incluindo a atualização
do catálogo e dos contatos. Não inclui histórico Git, credenciais ou configurações
de DNS da conta. O registro e a configuração do domínio são administrados à parte.

O carrinho prepara um pedido de orçamento pelo WhatsApp, sem processar pagamentos.
O formulário de novidades exibe uma confirmação local; não possui serviço de
cadastro ou envio de e-mails conectado.
