// Testes de ponta a ponta com um Postgres em memória (PGlite) e a API da Meta simulada.
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { PGlite } from '@electric-sql/pglite';
import { loadConfig } from '../src/config.js';
import { migrate, repo as makeRepo } from '../src/db.js';
import { createApp } from '../src/app.js';

const SECRET = 'segredo-de-teste-com-mais-de-24-caracteres';
const cfg = loadConfig({ MCP_SECRET: SECRET, WA_TOKEN: 'wa-token', WA_PHONE_NUMBER_ID: '123', WA_APP_SECRET: 'app-secret', WA_VERIFY_TOKEN: 'verifica',
  IG_TOKEN: 'ig-token', IG_APP_SECRET: 'ig-secret', IG_VERIFY_TOKEN: 'verifica-ig', SITE_WEBHOOK_TOKEN: 'site-token', PAINEL_SENHA: 'senha-do-painel-123' });
cfg.store = { catalogTtlMs: 0, ordersPerHour: 6 };   // nos testes o catálogo do site não fica em memória
const sent = [];
const fakeFetch = async (url, opts = {}) => {
  sent.push({ url, body: opts.body ? JSON.parse(opts.body) : null, headers: opts.headers });
  const json = (d, status = 200) => ({ ok: status < 400, status, json: async () => d });
  if (url.includes('graph.facebook.com') && JSON.parse(opts.body).to === '5511900000000') return json({ error: { code: 131047, message: 'Re-engagement message' } }, 400);
  if (url.includes('graph.facebook.com')) return json({ messages: [{ id: 'wamid.OUT1' }] });
  if (url.includes('graph.instagram.com') && url.includes('/messages')) return json({ recipient_id: 'IGSID1', message_id: 'mid.OUT1' });
  if (url.includes('graph.instagram.com') && url.includes('/m1/comments')) return json({ data: [
    { id: 'c1', text: 'Amei a agenda, ficou linda demais! 😍', username: 'prof.ana', timestamp: '2026-10-02T12:00:00+0000' },
    { id: 'c2', text: 'Quanto custa a agenda?', username: 'joana', timestamp: '2026-10-02T13:00:00+0000' },
    { id: 'c3', text: 'Meu pedido atrasou, ainda não chegou', username: 'bia', timestamp: '2026-10-02T14:00:00+0000' },
    { id: 'c4', text: 'Obrigada pelo carinho!', username: 'esro.papelaria', timestamp: '2026-10-02T15:00:00+0000' },
    { id: 'c5', text: 'Que capricho, parabéns pelo trabalho 👏', username: 'mari.prof', timestamp: '2026-10-03T12:00:00+0000' }] });
  if (url.includes('graph.instagram.com') && url.includes('/me/insights')) return json({ error: { code: 10, message: 'sem permissão' } }, 403);
  if (url.includes('graph.instagram.com') && url.includes('/me/media')) return json({ data: [
    { id: 'm1', caption: 'Agenda 2027\ncom nome na capa', media_type: 'IMAGE', permalink: 'https://www.instagram.com/p/abc/', timestamp: '2026-10-01T12:00:00+0000', like_count: 42, comments_count: 5 },
    { id: 'm2', media_type: 'VIDEO', media_product_type: 'REELS', permalink: 'javascript:alert(1)', timestamp: '2026-09-28T12:00:00+0000', like_count: 7, comments_count: 0 }] });
  if (url.includes('graph.instagram.com') && url.includes('/me?')) return json({ user_id: '1', username: 'esro.papelaria', name: 'ESRO', followers_count: 321, follows_count: 100, media_count: 18 });
  if (url.includes('graph.instagram.com')) return json({ name: 'Carol Mendes', username: 'prof.carol' });
  return json({}, 404);
};

let server, base, pg;
before(async () => {
  pg = new PGlite();
  const db = { q: (s, p) => pg.query(s, p), exec: (s) => pg.exec(s) };
  await migrate(db);
  const app = createApp({ cfg, repo: makeRepo(db), fetchImpl: fakeFetch, log: { error() {} } });
  server = app.listen(0); await new Promise(r => server.once('listening', r));
  base = `http://127.0.0.1:${server.address().port}`;
});
after(async () => { server.close(); await pg.close(); });

const sign = (secret, body) => 'sha256=' + crypto.createHmac('sha256', secret).update(body).digest('hex');
const post = (path, obj, headers = {}) => fetch(base + path, { method: 'POST', headers: { 'content-type': 'application/json', ...headers }, body: typeof obj === 'string' ? obj : JSON.stringify(obj) });
const wait = () => new Promise(r => setTimeout(r, 80));
let rpcId = 0;
async function mcp(tool, args = {}) {
  const r = await post(`/mcp/${SECRET}`, { jsonrpc: '2.0', id: ++rpcId, method: 'tools/call', params: { name: tool, arguments: args } }, { accept: 'application/json, text/event-stream' });
  const j = await r.json(); if (j.error) throw new Error(JSON.stringify(j.error));
  const text = j.result.content[0].text; return { isError: !!j.result.isError, data: j.result.isError ? text : JSON.parse(text) };
}

test('verificação do webhook', async () => {
  const ok = await fetch(`${base}/webhooks/whatsapp?hub.mode=subscribe&hub.verify_token=verifica&hub.challenge=42`);
  assert.equal(await ok.text(), '42');
  const bad = await fetch(`${base}/webhooks/whatsapp?hub.mode=subscribe&hub.verify_token=errado&hub.challenge=42`);
  assert.equal(bad.status, 403);
});

test('WhatsApp: recebe mensagem assinada, ignora assinatura inválida e registra eco do app', async () => {
  const body = JSON.stringify({ object: 'whatsapp_business_account', entry: [{ changes: [{ field: 'messages', value: {
    contacts: [{ wa_id: '5511974203381', profile: { name: 'Patrícia' } }],
    messages: [{ from: '5511974203381', id: 'wamid.IN1', timestamp: String(Math.floor(Date.now() / 1000) - 20), type: 'text', text: { body: 'Oi! Quanto custa a pauta?' } }] } }] }] });
  assert.equal((await post('/webhooks/whatsapp', body, { 'x-hub-signature-256': 'sha256=abc' })).status, 401);
  assert.equal((await post('/webhooks/whatsapp', body, { 'x-hub-signature-256': sign('app-secret', body) })).status, 200);
  // reenvio da Meta não duplica
  await post('/webhooks/whatsapp', body, { 'x-hub-signature-256': sign('app-secret', body) });
  const echo = JSON.stringify({ entry: [{ changes: [{ field: 'smb_message_echoes', value: { message_echoes: [{ from: '5511992481676', to: '5511974203381', id: 'wamid.ECHO1', timestamp: String(Math.floor(Date.now() / 1000) - 10), type: 'text', text: { body: 'Respondi pelo celular' } }] } }] }] });
  await post('/webhooks/whatsapp', echo, { 'x-hub-signature-256': sign('app-secret', echo) });
  await wait();
  const { data } = await mcp('listar_conversas');
  const c = data.conversas.find(x => x.id === 'whatsapp:5511974203381');
  assert.equal(c.nome, 'Patrícia'); assert.equal(c.nao_lidas, 1); assert.equal(c.pode_responder, true);
  const conv = await mcp('ler_conversa', { conversa_id: c.id });
  assert.deepEqual(conv.data.mensagens.map(m => [m.direcao, m.origem]), [['in', 'cliente'], ['out', 'app']]);
});

test('WhatsApp: envia pelo painel e trata janela de 24 h', async () => {
  const r = await mcp('enviar_mensagem', { conversa_id: 'whatsapp:5511974203381', texto: 'A pauta fica entre R$ 25 e R$ 45 💛' });
  assert.equal(r.isError, false); assert.equal(r.data.id, 'wamid.OUT1');
  const call = sent.find(s => s.url.includes('/123/messages'));
  assert.equal(call.body.to, '5511974203381'); assert.equal(call.headers.Authorization, 'Bearer wa-token');
  const conv = await mcp('ler_conversa', { conversa_id: 'whatsapp:5511974203381' });
  assert.equal(conv.data.conversa.nao_lidas, 0); assert.equal(conv.data.mensagens.at(-1).origem, 'painel');
  // cliente fora da janela
  const body = JSON.stringify({ entry: [{ changes: [{ value: { messages: [{ from: '5511900000000', id: 'wamid.OLD', timestamp: '1700000000', type: 'image', image: { id: 'm1', caption: 'referência' } }] } }] }] });
  await post('/webhooks/whatsapp', body, { 'x-hub-signature-256': sign('app-secret', body) }); await wait();
  const old = await mcp('ler_conversa', { conversa_id: 'whatsapp:5511900000000' });
  assert.equal(old.data.mensagens[0].texto, '[imagem] referência'); assert.equal(old.data.conversa.pode_responder, false);
  const e = await mcp('enviar_mensagem', { conversa_id: 'whatsapp:5511900000000', texto: 'Oi' });
  assert.equal(e.isError, true); assert.match(e.data, /24 h/);
});

test('Instagram: recebe DM, busca @ do cliente e responde', async () => {
  const body = JSON.stringify({ object: 'instagram', entry: [{ id: '1789', time: Date.now(), messaging: [{ sender: { id: 'IGSID1' }, recipient: { id: '1789' }, timestamp: Date.now(), message: { mid: 'mid.IN1', text: 'Amei a agenda!' } }] }] });
  assert.equal((await post('/webhooks/instagram', body, { 'x-hub-signature-256': sign('ig-secret', body) })).status, 200); await wait();
  const { data } = await mcp('listar_conversas', { canal: 'instagram' });
  assert.equal(data.conversas[0].contato, '@prof.carol');
  const r = await mcp('enviar_mensagem', { conversa_id: 'instagram:IGSID1', texto: 'Obrigada, Carol!' });
  assert.equal(r.data.id, 'mid.OUT1');
  assert.deepEqual(sent.find(s => s.url.includes('graph.instagram.com') && s.url.includes('/messages')).body, { recipient: { id: 'IGSID1' }, message: { text: 'Obrigada, Carol!' } });
});

test('Pedidos do site: exige token, evita duplicado e marca importado', async () => {
  assert.equal((await post('/webhooks/site', { numero: 'W1050' })).status, 401);
  const r = await post('/webhooks/site', { numero: 'W1050', cliente: 'Juliana', itens: [{ nome: 'Planner personalizado', qtd: 1, valor: 78 }], total: 78 }, { 'x-esro-token': 'site-token' });
  assert.equal(r.status, 201);
  assert.equal((await post('/webhooks/site', { numero: 'W1050' }, { 'x-esro-token': 'site-token' })).status, 200);
  const l = await mcp('listar_pedidos_site');
  assert.equal(l.data.pedidos.length, 1); assert.equal(l.data.pedidos[0].dados.cliente, 'Juliana');
  await mcp('marcar_pedido_importado', { pedido_id: l.data.pedidos[0].id });
  assert.equal((await mcp('listar_pedidos_site')).data.pedidos.length, 0);
});

test('MCP: segredo errado não expõe nada e ferramentas estão listadas', async () => {
  assert.equal((await post('/mcp/errado', { jsonrpc: '2.0', id: 1, method: 'tools/list' }, { accept: 'application/json, text/event-stream' })).status, 404);
  const r = await post(`/mcp/${SECRET}`, { jsonrpc: '2.0', id: 1, method: 'tools/list' }, { accept: 'application/json, text/event-stream' });
  const names = (await r.json()).result.tools.map(t => t.name).sort();
  assert.deepEqual(names, ['enviar_mensagem', 'ler_conversa', 'listar_conversas', 'listar_pedidos_site', 'marcar_como_lida', 'marcar_pedido_importado', 'status_conexoes']);
  const st = await mcp('status_conexoes');
  assert.equal(st.data.whatsapp.configurado, true); assert.equal(st.data.pedidos_site_novos, 0);
});

/* ---------- Segurança ---------- */
test('Segurança: cabeçalhos, 404 genérico e JSON inválido sem detalhes', async () => {
  const r = await fetch(base + '/healthz');
  assert.match(r.headers.get('strict-transport-security'), /max-age=31536000/);
  assert.equal(r.headers.get('x-content-type-options'), 'nosniff'); assert.equal(r.headers.get('x-frame-options'), 'DENY');
  assert.match(r.headers.get('content-security-policy'), /default-src 'none'/); assert.equal(r.headers.get('x-powered-by'), null);
  const nf = await fetch(base + '/qualquer/coisa'); assert.equal(nf.status, 404); assert.deepEqual(await nf.json(), { erro: 'não encontrado' });
  const bad = await post('/webhooks/site', '{invalido', { 'x-esro-token': 'site-token' }); assert.equal(bad.status, 400); assert.deepEqual(await bad.json(), { erro: 'JSON inválido.' });
  const http = await fetch(base + '/', { headers: { 'x-forwarded-proto': 'http' }, redirect: 'manual' }); assert.equal(http.status, 308); assert.match(http.headers.get('location'), /^https:\/\//);
  assert.equal((await post('/webhooks/site', { numero: 'X1' }, { 'x-esro-token': 'site-token', 'x-forwarded-proto': 'http' })).status, 400);
});

test('Segurança: webhook sem assinatura é recusado e o conteúdo bruto não é guardado', async () => {
  const body = JSON.stringify({ entry: [{ messaging: [{ sender: { id: 'FALSO' }, recipient: { id: '1789' }, timestamp: Date.now(), message: { mid: 'mid.FALSO', text: 'mensagem forjada' } }] }] });
  assert.equal((await post('/webhooks/instagram', body)).status, 401);
  assert.equal((await post('/webhooks/instagram', body, { 'x-hub-signature-256': sign('chave-errada', body) })).status, 401);
  // sem a chave secreta configurada, nada é aceito (antes aceitava)
  const cfg2 = loadConfig({ MCP_SECRET: SECRET, IG_TOKEN: 'ig-token', WA_TOKEN: 'wa', WA_PHONE_NUMBER_ID: '1' });
  const app2 = createApp({ cfg: cfg2, repo: makeRepo({ q: (s, p) => pg.query(s, p) }), fetchImpl: fakeFetch, log: { error() {}, warn() {} } });
  const s2 = app2.listen(0); await new Promise(r => s2.once('listening', r)); const b2 = `http://127.0.0.1:${s2.address().port}`;
  const p2 = (path, h = {}) => fetch(b2 + path, { method: 'POST', headers: { 'content-type': 'application/json', ...h }, body });
  assert.equal((await p2('/webhooks/instagram')).status, 401); assert.equal((await p2('/webhooks/instagram', { 'x-hub-signature-256': sign('', body) })).status, 401);
  assert.equal((await p2('/webhooks/whatsapp')).status, 401);
  s2.close(); await wait();
  assert.equal((await pg.query(`SELECT count(*)::int AS n FROM contacts WHERE peer_id='FALSO'`)).rows[0].n, 0);
  assert.equal((await pg.query('SELECT count(*)::int AS n FROM messages WHERE raw IS NOT NULL')).rows[0].n, 0);
});

test('Segurança: tabelas fechadas para a API pública do banco (RLS)', async () => {
  const r = await pg.query(`SELECT relname, relrowsecurity FROM pg_class WHERE relname IN ('contacts','messages','site_orders','kv','panel_docs','panel_assets','site_stats','social_stats','site_users','panel_users') ORDER BY relname`);
  assert.deepEqual(r.rows.map(x => [x.relname, x.relrowsecurity]), [['contacts', true], ['kv', true], ['messages', true], ['panel_assets', true], ['panel_docs', true], ['panel_users', true], ['site_orders', true], ['site_stats', true], ['site_users', true], ['social_stats', true]]);
});

test('Segurança: bloqueio após tentativas com segredo errado e limite de requisições', async () => {
  const cfg3 = loadConfig({ MCP_SECRET: SECRET, SITE_WEBHOOK_TOKEN: 'site-token', AUTH_FAILURES_LIMIT: '5', RATE_LIMIT_PER_MINUTE: '40' });
  const warns = []; const app3 = createApp({ cfg: cfg3, repo: makeRepo({ q: (s, p) => pg.query(s, p) }), fetchImpl: fakeFetch, log: { error() {}, warn: (m) => warns.push(m) } });
  const s3 = app3.listen(0); await new Promise(r => s3.once('listening', r)); const b3 = `http://127.0.0.1:${s3.address().port}`;
  const call = (path, ip, h = {}) => fetch(b3 + path, { method: 'POST', headers: { 'content-type': 'application/json', accept: 'application/json, text/event-stream', 'cf-connecting-ip': ip, ...h }, body: JSON.stringify({ jsonrpc: '2.0', id: 1, method: 'tools/list' }) });
  for (let i = 0; i < 5; i++) assert.equal((await call('/mcp/chute-' + i, '203.0.113.9')).status, 404);
  const blocked = await call('/mcp/' + SECRET, '203.0.113.9'); assert.equal(blocked.status, 429); assert.ok(Number(blocked.headers.get('retry-after')) > 0);
  assert.equal((await call('/webhooks/site', '203.0.113.9', { 'x-esro-token': 'site-token' })).status, 429);
  assert.equal(warns.length, 1); assert.match(warns[0], /bloqueado/);
  assert.equal((await call('/mcp/' + SECRET, '198.51.100.7')).status, 200);   // outro endereço segue funcionando
  let last = 0; for (let i = 0; i < 45; i++) last = (await fetch(b3 + '/', { headers: { 'cf-connecting-ip': '192.0.2.50' } })).status;
  assert.equal(last, 429);
  s3.close();
});

/* ---------- Site e painel próprio ---------- */
const H = { 'x-esro': '1', 'content-type': 'application/json' };
const api = (method, path, body, cookie, extra = {}) => fetch(base + '/painel/api' + path, { method, headers: { ...H, ...(cookie ? { cookie } : {}), ...extra }, body: body === undefined ? undefined : (Buffer.isBuffer(body) ? body : JSON.stringify(body)) });
async function login() { const r = await api('POST', '/login', { senha: 'senha-do-painel-123' }); assert.equal(r.status, 204); const c = r.headers.get('set-cookie'); assert.match(c, /HttpOnly/); assert.match(c, /SameSite=Strict/); return c.split(';')[0]; }

test('Site: página pública na raiz, com política de segurança e sem scripts embutidos', async () => {
  const r = await fetch(base + '/'); assert.equal(r.status, 200); assert.match(r.headers.get('content-type'), /text\/html/);
  const html = await r.text(); assert.match(html, /ESRO/); assert.ok(!/<script>/.test(html)); assert.match(html, /href="\/painel"/);
  assert.match(r.headers.get('content-security-policy'), /script-src 'self';/);
  assert.equal((await fetch(base + '/site.js')).status, 200); assert.equal((await fetch(base + '/assets/esro-contato.jpg')).headers.get('content-type'), 'image/jpeg');
  // Vitrine: cada produto tem a sua ilustração, servida como imagem e sem nada executável dentro
  const pics = [...html.matchAll(/<img src="(assets\/produtos\/[\w-]+\.svg)" alt="([^"]+)"/g)]; assert.equal(pics.length, 8); assert.equal(new Set(pics.map(m => m[1])).size, 8);
  for (const [, src] of pics) { const im = await fetch(base + '/' + src); assert.equal(im.status, 200); assert.match(im.headers.get('content-type'), /image\/svg\+xml/);
    const svg = await im.text(); assert.ok(!/<script|<foreignObject|\son\w+=|href=/i.test(svg)); assert.ok(svg.length < 60000); }
  assert.match(await (await fetch(base + '/robots.txt')).text(), /Disallow: \/painel/);
  const sm = await fetch(base + '/sitemap.xml'); assert.equal(sm.status, 200); assert.match(sm.headers.get('content-type'), /xml/); assert.ok((await sm.text()).includes(`<loc>${base}/</loc>`)); assert.match(html, /property="og:image"/);
  assert.equal((await fetch(base + '/../src/config.js')).status, 404); assert.equal((await fetch(base + '/.env')).status, 404);
});

test('Painel: página abre sem dados; API exige login, cabeçalho próprio e mesma origem', async () => {
  const page = await fetch(base + '/painel'); assert.equal(page.status, 200); assert.match(page.headers.get('content-security-policy'), /script-src 'self';/); assert.match(page.headers.get('x-robots-tag'), /noindex/);
  const html = await page.text(); assert.ok(!/<script>/.test(html)); assert.match(html, /\/painel\/runtime\.js/);
  assert.equal((await fetch(base + '/painel/app.js')).status, 200);
  assert.equal((await api('GET', '/sync')).status, 401); assert.equal((await api('GET', '/me')).status, 401);
  assert.equal((await api('PUT', '/db/orders/x1', { a: 1 })).status, 401); assert.equal((await fetch(base + '/_blob/' + 'a'.repeat(24))).status, 401);
  assert.equal((await api('POST', '/login', { senha: 'errada' })).status, 401);
  const cookie = await login();
  assert.equal((await api('GET', '/me', undefined, cookie)).status, 200);
  assert.equal((await fetch(base + '/painel/api/me', { headers: { cookie } })).status, 400);                              // sem o cabeçalho próprio
  assert.equal((await api('GET', '/me', undefined, cookie, { origin: 'https://site-malicioso.example' })).status, 403);     // outra origem
  assert.equal((await api('GET', '/me', undefined, cookie.slice(0, -3) + 'abc')).status, 401);                             // sessão adulterada
  assert.equal((await api('GET', '/me', undefined, 'esro_sess=' + (Date.now() - 1000) + '.x.y')).status, 401);
  const out = await api('POST', '/logout', {}, cookie); assert.match(out.headers.get('set-cookie'), /Max-Age=0/);
});

test('Painel: gravar, alterar, excluir e sincronizar documentos', async () => {
  const cookie = await login();
  const s0 = await (await api('GET', '/sync?after=0', undefined, cookie)).json();
  assert.equal((await api('PUT', '/db/orders/p1', { num: 1001, client: 'Ana', value: 40, notes: [{ t: 'a' }] }, cookie)).status, 200);
  const merged = await (await api('PATCH', '/db/orders/p1', { value: 55, status: 'novo' }, cookie)).json();
  assert.deepEqual(merged.data, { num: 1001, client: 'Ana', value: 55, status: 'novo', notes: [{ t: 'a' }] });
  await api('PUT', '/db/settings/store', { pixKey: 'chave' }, cookie); await api('PATCH', '/db/clients/novo', { name: 'Criado pelo update' }, cookie);
  const s1 = await (await api('GET', '/sync?after=' + s0.seq, undefined, cookie)).json();
  assert.deepEqual(s1.docs.map(d => [d.col, d.id]).sort(), [['clients', 'novo'], ['orders', 'p1'], ['settings', 'store']]); assert.ok(s1.seq > s0.seq);
  await api('DELETE', '/db/orders/p1', undefined, cookie);
  const s2 = await (await api('GET', '/sync?after=' + s1.seq, undefined, cookie)).json();
  assert.deepEqual(s2.docs, [{ col: 'orders', id: 'p1', del: true }]);
  assert.equal((await pg.query(`SELECT data::text AS d FROM panel_docs WHERE col='orders' AND id='p1'`)).rows[0].d, '{}');   // o conteúdo some de verdade
  assert.equal((await api('PUT', '/db/segredos/x', { a: 1 }, cookie)).status, 400); assert.equal((await api('PUT', '/db/orders/..%2Fx', { a: 1 }, cookie)).status, 400);
  assert.equal((await api('PUT', '/db/orders/p2', [1, 2], cookie)).status, 400);
  assert.equal((await api('PUT', '/db/orders/p3', { big: 'x'.repeat(300 * 1024) }, cookie)).status, 413);
});

test('Painel: arquivos só com login, tipo conferido e nunca executáveis', async () => {
  const cookie = await login(); const png = Buffer.from('89504e470d0a1a0a0000000d49484452', 'hex');
  const up = await api('POST', '/assets?name=capa%20floral.png', png, cookie, { 'content-type': 'image/png' }); assert.equal(up.status, 201);
  const a = await up.json(); assert.match(a.id, /^[a-f0-9]{24}$/); assert.equal(a.url, '/_blob/' + a.id); assert.equal(a.sizeBytes, png.length);
  assert.equal((await fetch(base + a.url)).status, 401);
  const got = await fetch(base + a.url, { headers: { cookie } }); assert.equal(got.status, 200); assert.equal(got.headers.get('content-type'), 'image/png');
  assert.match(got.headers.get('content-security-policy'), /sandbox/); assert.match(got.headers.get('content-disposition'), /^inline/); assert.deepEqual(Buffer.from(await got.arrayBuffer()), png);
  assert.equal((await api('POST', '/assets?name=x.html', Buffer.from('<script>alert(1)</script>'), cookie, { 'content-type': 'text/html' })).status, 415);
  const js = await (await api('POST', '/assets?name=dados.json', Buffer.from('{"a":1}'), cookie, { 'content-type': 'application/json' })).json();
  assert.match((await fetch(base + js.url, { headers: { cookie } })).headers.get('content-disposition'), /^attachment/);
  const svg = await (await api('POST', '/assets?name=a.svg', Buffer.from('<svg xmlns="http://www.w3.org/2000/svg"/>'), cookie, { 'content-type': 'image/svg+xml' })).json();
  assert.match((await fetch(base + svg.url, { headers: { cookie } })).headers.get('content-disposition'), /^attachment/);
  assert.equal((await (await api('GET', '/assets', undefined, cookie)).json()).assets.length, 3);
  assert.equal((await api('DELETE', '/assets/' + a.id, undefined, cookie)).status, 204); assert.equal((await fetch(base + a.url, { headers: { cookie } })).status, 404);
});

test('Painel: ferramentas de mensagens pelo próprio servidor', async () => {
  const cookie = await login();
  const st = await (await api('POST', '/tool/status_conexoes', {}, cookie)).json(); assert.equal(st.whatsapp.configurado, true);
  const l = await (await api('POST', '/tool/listar_conversas', { limite: 10 }, cookie)).json(); assert.ok(l.conversas.length >= 2);
  const bad = await api('POST', '/tool/ler_conversa', { conversa_id: 'whatsapp:000' }, cookie); assert.equal(bad.status, 422); assert.deepEqual(await bad.json(), { erro: 'Conversa não encontrada.' });
  assert.equal((await api('POST', '/tool/listar_conversas', { limite: 'muitos' }, cookie)).status, 422); assert.equal((await api('POST', '/tool/apagar_tudo', {}, cookie)).status, 404);
  assert.equal((await api('POST', '/tool/status_conexoes', {})).status, 401);
});

test('Painel: sem PAINEL_SENHA fica desativado; senha errada repetida bloqueia o endereço', async () => {
  const mk = async (env) => { const a = createApp({ cfg: loadConfig({ MCP_SECRET: SECRET, AUTH_FAILURES_LIMIT: '4', ...env }), repo: makeRepo({ q: (s, p) => pg.query(s, p) }), fetchImpl: fakeFetch, log: { error() {}, warn() {} } }); const s = a.listen(0); await new Promise(r => s.once('listening', r)); return [s, `http://127.0.0.1:${s.address().port}`]; };
  const [s1, b1] = await mk({}); const [s2, b2] = await mk({ PAINEL_SENHA: 'curta' }); const [s3, b3] = await mk({ PAINEL_SENHA: 'uma-senha-bem-grande' });
  for (const b of [b1, b2]) { const r = await fetch(b + '/painel/api/login', { method: 'POST', headers: H, body: JSON.stringify({ senha: 'curta' }) }); assert.equal(r.status, 503); assert.match((await r.json()).erro, /PAINEL_SENHA/); }
  const tryLogin = (senha) => fetch(b3 + '/painel/api/login', { method: 'POST', headers: { ...H, 'cf-connecting-ip': '203.0.113.77' }, body: JSON.stringify({ senha }) });
  for (let i = 0; i < 4; i++) assert.equal((await tryLogin('chute' + i)).status, 401);
  assert.equal((await tryLogin('uma-senha-bem-grande')).status, 429);
  s1.close(); s2.close(); s3.close();
});

/* ---------- Contas de clientes do site ---------- */
const CH = { 'content-type': 'application/json', 'x-esro': '1' };
const conta = (method, path, body, cookie, extra = {}) => fetch(base + '/api/conta' + path, { method, headers: { ...CH, ...(cookie ? { cookie } : {}), ...extra }, body: body ? JSON.stringify(body) : undefined });
const cookieFrom = (r) => (r.headers.get('set-cookie') || '').split(';')[0];
const novo = (over = {}) => ({ nome: 'Marina Souza', email: 'marina@exemplo.com', telefone: '11 98765-4321', senha: 'caderno-azul-27', aceite: true, ...over });

test('Conta: páginas públicas abrem sem scripts embutidos e o cadastro confere cada campo', async () => {
  for (const p of ['/entrar', '/conta', '/privacidade']) {
    const r = await fetch(base + p); assert.equal(r.status, 200, p); assert.match(r.headers.get('content-security-policy'), /script-src 'self';/);
    const html = await r.text(); assert.ok(!/<script>/.test(html) && !/ on\w+="/.test(html), p + ' sem script embutido');
  }
  assert.equal((await fetch(base + '/conta.js')).status, 200); assert.equal((await fetch(base + '/conta.css')).status, 200);
  const ip = { 'cf-connecting-ip': '198.51.100.10' };
  assert.equal((await fetch(base + '/api/conta/cadastro', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(novo()) })).status, 400);   // sem o cabeçalho próprio
  assert.equal((await conta('POST', '/cadastro', novo(), null, { origin: 'https://site-malicioso.example' })).status, 403);
  for (const [over, campo] of [[{ nome: ' ' }, 'nome'], [{ email: 'marina@' }, 'email'], [{ telefone: '1234' }, 'telefone'], [{ senha: 'curta' }, 'senha'], [{ senha: '12345678' }, 'senha'], [{ senha: 'marina@exemplo.com' }, 'senha'], [{ aceite: false }, 'aceite']]) {
    const r = await conta('POST', '/cadastro', novo(over), null, ip); assert.equal(r.status, 422, campo); assert.equal((await r.json()).campo, campo);
  }
  assert.equal((await conta('POST', '/cadastro', novo({ site: 'http://spam' }), null, ip)).status, 400);                     // campo-armadilha preenchido
  assert.equal((await conta('GET', '/eu')).status, 401);
  assert.deepEqual(await (await conta('GET', '/sessao')).json(), { conta: null });
});

test('Conta: cadastro cria login e ficha no painel; a senha fica só embaralhada', async () => {
  const ip = { 'cf-connecting-ip': '198.51.100.11' };
  const r = await conta('POST', '/cadastro', novo({ email: '  Marina@Exemplo.com ' }), null, ip); assert.equal(r.status, 201);
  const sc = r.headers.get('set-cookie'); assert.match(sc, /^esro_cli=/); assert.match(sc, /HttpOnly/); assert.match(sc, /SameSite=Lax/);
  assert.deepEqual((await r.json()).conta.telefone, '(11) 98765-4321');
  const cookie = cookieFrom(r);
  const me = await (await conta('GET', '/eu', null, cookie)).json(); assert.equal(me.conta.email, 'marina@exemplo.com'); assert.equal(me.conta.nome, 'Marina Souza');
  assert.equal(Object.keys(me.conta).sort().join(), 'desde,email,nome,telefone');
  const row = (await pg.query(`SELECT * FROM site_users WHERE email = 'marina@exemplo.com'`)).rows[0];
  assert.match(row.pass_hash, /^scrypt\$15\$8\$1\$/); assert.ok(!JSON.stringify(row).includes('caderno-azul-27'));
  const ficha = (await pg.query(`SELECT data FROM panel_docs WHERE col = 'clients' AND id = $1`, [row.client_id])).rows[0].data;
  assert.equal(ficha.origin, 'site'); assert.equal(ficha.siteUser, row.id); assert.equal(ficha.phone, '(11) 98765-4321'); assert.equal(ficha.stage, 'info');
  const dup = await conta('POST', '/cadastro', novo({ senha: 'outra-senha-99' }), null, ip); assert.equal(dup.status, 409); assert.equal((await dup.json()).campo, 'email');
  assert.equal((await conta('GET', '/eu', null, cookie.slice(0, -4) + 'abcd')).status, 401);                                // sessão adulterada
});

test('Conta: entrar, sair, mensagem igual para e-mail inexistente e senha errada', async () => {
  const ip = { 'cf-connecting-ip': '198.51.100.12' };
  const a = await conta('POST', '/entrar', { email: 'marina@exemplo.com', senha: 'errada-errada' }, null, ip);
  const b = await conta('POST', '/entrar', { email: 'ninguem@exemplo.com', senha: 'errada-errada' }, null, ip);
  assert.equal(a.status, 401); assert.equal(b.status, 401); assert.deepEqual(await a.json(), await b.json());
  const ok = await conta('POST', '/entrar', { email: 'MARINA@exemplo.com', senha: 'caderno-azul-27' }, null, ip); assert.equal(ok.status, 200);
  const cookie = cookieFrom(ok);
  assert.equal((await (await conta('GET', '/sessao', null, cookie)).json()).conta.nome, 'Marina Souza');
  const out = await conta('POST', '/sair', {}, cookie); assert.equal(out.status, 204); assert.match(out.headers.get('set-cookie'), /Max-Age=0/);
});

test('Conta: o cliente só vê os próprios pedidos; dados alterados vão para a ficha', async () => {
  const ip = { 'cf-connecting-ip': '198.51.100.13' };
  const cookie = cookieFrom(await conta('POST', '/entrar', { email: 'marina@exemplo.com', senha: 'caderno-azul-27' }, null, ip));
  const row = (await pg.query(`SELECT * FROM site_users WHERE email = 'marina@exemplo.com'`)).rows[0];
  const adm = await login();
  await api('PUT', '/db/orders/pm1', { num: 2001, at: '2026-10-01T12:00:00.000Z', client: 'Marina Souza', clientId: row.client_id, item: 'Planner personalizado', qty: 2, value: 150, status: 'producao', payS: 'Sinal pago', due: '2026-10-20', note: 'anotação interna' }, adm);
  await api('PUT', '/db/orders/pm2', { num: 2002, at: '2026-10-02T12:00:00.000Z', client: 'Outra Pessoa', clientId: 'cli_outra', item: 'Agenda', value: 60, status: 'novo' }, adm);
  await api('PUT', '/db/orders/pm3', { num: 2003, at: '2026-10-03T12:00:00.000Z', client: 'Marina Souza', contact: '(11) 98765-4321', item: 'Sem vínculo', value: 10, status: 'novo' }, adm);   // mesmo telefone, sem vínculo: não aparece
  const antes = (await pg.query(`SELECT data FROM panel_docs WHERE col = 'settings' AND id = 'store' AND deleted = false`)).rows[0]?.data;   // configurações deixadas por outros testes
  await api('DELETE', '/db/settings/store', undefined, adm);
  const { pedidos } = await (await conta('GET', '/pedidos', null, cookie)).json();
  assert.equal(pedidos.length, 1);
  // Sem chave PIX cadastrada no painel não há código de pagamento; "sinal pago" sem valor informado conta como metade.
  assert.deepEqual(pedidos[0], { numero: 2001, data: '2026-10-01T12:00:00.000Z', item: 'Planner personalizado', quantidade: 2, valor: 150, pago: 75, falta: 75, status: 'producao', statusNome: 'Em produção', entrega: '2026-10-20', pagamento: 'Sinal pago', pix: null, acompanhar: null, rastreio: null, depoimento: null });
  // Com a chave PIX cadastrada, o cliente recebe o "copia e cola" só do valor que falta, com o código de conferência (CRC) correto.
  await api('PUT', '/db/settings/store', { pixType: 'cpf', pixKey: '12.345.678/0001-95', pixName: 'ESRO Papelaria', pixCity: 'São Paulo' }, adm);
  await api('PUT', '/db/orders/pm4', { num: 2004, at: '2026-10-04T12:00:00.000Z', client: 'Marina Souza', clientId: row.client_id, item: 'Agenda', value: 60, status: 'concluido', payS: 'Pago', pays: [{ at: '2026-10-04T12:00:00.000Z', value: 60 }] }, adm);
  const comPix = (await (await conta('GET', '/pedidos', null, cookie)).json()).pedidos;
  const p1 = comPix.find(p => p.numero === 2001), p4 = comPix.find(p => p.numero === 2004);
  assert.equal(p4.pix, null); assert.equal(p4.falta, 0); assert.equal(p4.pago, 60);
  assert.equal(p1.pix.valor, 75); assert.equal(p1.pix.favorecido, 'ESRO Papelaria');
  const code = p1.pix.codigo; assert.match(code, /^000201/); assert.ok(code.includes('0014br.gov.bcb.pix0114' + '12345678000195')); assert.ok(code.includes('540575.00')); assert.ok(code.includes('5914ESRO PAPELARIA')); assert.ok(code.includes('6009SAO PAULO')); assert.ok(code.includes('0508ESRO2001'));
  const { crc16 } = await import('../src/pix.js'); assert.equal(code.slice(-4), crc16(code.slice(0, -4))); assert.equal(crc16('123456789'), '29B1');   // valor de referência do CRC-16/CCITT-FALSE
  await api('DELETE', '/db/orders/pm4', undefined, adm);
  if (antes) await api('PUT', '/db/settings/store', antes, adm); else await api('DELETE', '/db/settings/store', undefined, adm);
  assert.equal((await conta('GET', '/pedidos')).status, 401);
  const bad = await conta('PATCH', '/eu', { nome: 'Marina S. Lima', telefone: '99' }, cookie); assert.equal(bad.status, 422);
  const up = await conta('PATCH', '/eu', { nome: 'Marina S. Lima', telefone: '(21) 3333-4444' }, cookie); assert.equal((await up.json()).conta.telefone, '(21) 3333-4444');
  const ficha = (await pg.query(`SELECT data FROM panel_docs WHERE col = 'clients' AND id = $1`, [row.client_id])).rows[0].data;
  assert.equal(ficha.name, 'Marina S. Lima'); assert.equal(ficha.phone, '(21) 3333-4444'); assert.equal(ficha.siteUser, row.id); assert.match(ficha.notes.at(-1).text, /Atualizou/);
});

test('Conta: trocar a senha encerra as outras sessões; link de senha nova é do painel, de uso único', async () => {
  const ip = { 'cf-connecting-ip': '198.51.100.14' };
  const enter = async (senha) => conta('POST', '/entrar', { email: 'marina@exemplo.com', senha }, null, ip);
  const c1 = cookieFrom(await enter('caderno-azul-27')), c2 = cookieFrom(await enter('caderno-azul-27'));
  assert.equal((await conta('POST', '/senha', { atual: 'errada-errada', nova: 'lapis-verde-88' }, c1, ip)).status, 422);
  assert.equal((await conta('POST', '/senha', { atual: 'caderno-azul-27', nova: 'curta' }, c1, ip)).status, 422);
  const ch = await conta('POST', '/senha', { atual: 'caderno-azul-27', nova: 'lapis-verde-88' }, c1, ip); assert.equal(ch.status, 200);
  assert.equal((await conta('GET', '/eu', null, c2)).status, 401); assert.equal((await conta('GET', '/eu', null, c1)).status, 401);
  assert.equal((await conta('GET', '/eu', null, cookieFrom(ch))).status, 200);
  assert.equal((await enter('caderno-azul-27')).status, 401); assert.equal((await enter('lapis-verde-88')).status, 200);

  const row = (await pg.query(`SELECT * FROM site_users WHERE email = 'marina@exemplo.com'`)).rows[0];
  assert.equal((await api('POST', `/contas/${row.client_id}/link-senha`, {})).status, 401);                                 // só com login do painel
  const adm = await login();
  assert.equal((await api('POST', '/contas/cli_inexistente/link-senha', {}, adm)).status, 404);
  const link = await (await api('POST', `/contas/${row.client_id}/link-senha`, {}, adm)).json();
  const token = /\/entrar#nova-senha=([\w-]{40,60})$/.exec(link.url)[1];
  const stored = (await pg.query(`SELECT reset_hash FROM site_users WHERE id = $1`, [row.id])).rows[0].reset_hash;
  assert.ok(stored && stored !== token && !stored.includes(token));                                                         // o banco guarda só o sha256 do código
  assert.equal((await conta('POST', '/nova-senha', { token: 'x'.repeat(43), senha: 'tesoura-rosa-55' }, null, ip)).status, 400);
  assert.equal((await conta('POST', '/nova-senha', { token, senha: 'curta' }, null, ip)).status, 422);
  const rs = await conta('POST', '/nova-senha', { token, senha: 'tesoura-rosa-55' }, null, ip); assert.equal(rs.status, 200); assert.match(rs.headers.get('set-cookie'), /^esro_cli=/);
  assert.equal((await conta('POST', '/nova-senha', { token, senha: 'tesoura-rosa-56' }, null, ip)).status, 400);            // não funciona duas vezes
  assert.equal((await enter('lapis-verde-88')).status, 401); assert.equal((await enter('tesoura-rosa-55')).status, 200);
});

test('Conta: unir com ficha antiga pelo painel e excluir a conta', async () => {
  const ip = { 'cf-connecting-ip': '198.51.100.15' };
  const adm = await login();
  await api('PUT', '/db/clients/cli_antiga', { name: 'Marina (ficha antiga)', phone: '(21) 3333-4444', notes: [] }, adm);
  await api('PUT', '/db/orders/pa1', { num: 1500, at: '2026-08-10T12:00:00.000Z', client: 'Marina', clientId: 'cli_antiga', item: 'Caderno em brochura', value: 40, status: 'concluido', payS: 'Pago' }, adm);
  const row = (await pg.query(`SELECT * FROM site_users WHERE email = 'marina@exemplo.com'`)).rows[0];
  assert.equal((await api('POST', `/contas/${row.client_id}/mover`, { para: 'cli_nao_existe' }, adm)).status, 422);
  assert.equal((await api('POST', `/contas/${row.client_id}/mover`, { para: 'cli_antiga' }, adm)).status, 200);
  const cookie = cookieFrom(await conta('POST', '/entrar', { email: 'marina@exemplo.com', senha: 'tesoura-rosa-55' }, null, ip));
  const { pedidos } = await (await conta('GET', '/pedidos', null, cookie)).json();
  assert.deepEqual(pedidos.map(p => p.numero), [1500]);
  const antiga = (await pg.query(`SELECT data FROM panel_docs WHERE col = 'clients' AND id = 'cli_antiga'`)).rows[0].data; assert.equal(antiga.siteUser, row.id);

  assert.equal((await conta('POST', '/excluir', { senha: 'errada-errada' }, cookie, ip)).status, 422);
  const del = await conta('POST', '/excluir', { senha: 'tesoura-rosa-55' }, cookie, ip); assert.equal(del.status, 204);
  assert.equal((await conta('GET', '/eu', null, cookie)).status, 401);
  assert.equal((await conta('POST', '/entrar', { email: 'marina@exemplo.com', senha: 'tesoura-rosa-55' }, null, ip)).status, 401);
  assert.equal((await pg.query(`SELECT count(*)::int AS n FROM site_users`)).rows[0].n, 0);
  const depois = (await pg.query(`SELECT data FROM panel_docs WHERE col = 'clients' AND id = 'cli_antiga'`)).rows[0].data;
  assert.equal(depois.siteUser, null); assert.match(depois.notes.at(-1).text, /Excluiu a conta/);
});

test('Conta: tentativas demais bloqueiam o endereço e o cadastro tem limite por hora', async () => {
  const a = createApp({ cfg: loadConfig({ MCP_SECRET: SECRET, AUTH_FAILURES_LIMIT: '4' }), repo: makeRepo({ q: (s, p) => pg.query(s, p) }), fetchImpl: fakeFetch, log: { error() {}, warn() {} } });
  const s = a.listen(0); await new Promise(r => s.once('listening', r)); const b = `http://127.0.0.1:${s.address().port}`;
  const call = (path, body, ip) => fetch(b + '/api/conta' + path, { method: 'POST', headers: { ...CH, 'cf-connecting-ip': ip }, body: JSON.stringify(body) });
  for (let i = 0; i < 4; i++) assert.equal((await call('/entrar', { email: 'alguem@exemplo.com', senha: 'chute-numero-' + i }, '203.0.113.90')).status, 401);
  assert.equal((await call('/entrar', { email: 'alguem@exemplo.com', senha: 'qualquer-coisa' }, '203.0.113.90')).status, 429);
  for (let i = 0; i < 5; i++) assert.equal((await call('/cadastro', novo({ email: `cliente${i}@exemplo.com` }), '203.0.113.91')).status, 201);
  const lim = await call('/cadastro', novo({ email: 'cliente9@exemplo.com' }), '203.0.113.91'); assert.equal(lim.status, 429); assert.ok(Number(lim.headers.get('retry-after')) > 0);
  await pg.query(`DELETE FROM site_users WHERE email LIKE 'cliente%@exemplo.com'`);
  s.close();
});

/* ---------- Loja: ligação entre o site e o painel ---------- */
const UA = 'Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0 Mobile Safari/537.36';
const loja = (method, path, body, cookie, extra = {}) => fetch(base + '/api' + path, { method, headers: { ...CH, 'user-agent': UA, ...(cookie ? { cookie } : {}), ...extra }, body: body ? JSON.stringify(body) : undefined });
const CAT7 = { n: '07', t: 'Papelaria personalizada', d: 'Produtos físicos em brochura', kind: 'fisico', items: [
  { name: 'Agenda personalizada', min: 45, max: 85, on: true }, { name: 'Planner personalizado', min: 45, max: 90, on: true }, { name: 'Item desligado', min: 1, max: 2, on: false }] };

test('Loja: o catálogo do site vem do painel e muda quando o painel muda', async () => {
  const c = await login();
  await api('PUT', '/db/catalog/c07', CAT7, c); await api('PUT', '/db/catalog/c02', { n: '02', t: 'Materiais pedagógicos', d: '', kind: 'digital', items: [{ name: 'Slides de formação', min: 35, max: 90, on: true }] }, c);
  const r = await fetch(base + '/api/catalogo'); assert.equal(r.status, 200); assert.match(r.headers.get('cache-control'), /max-age=60/);
  const { categorias } = await r.json(); assert.deepEqual(categorias.map(x => x.n), ['02', '07']);
  assert.deepEqual(categorias[1].itens, [{ nome: 'Agenda personalizada', min: 45, max: 85 }, { nome: 'Planner personalizado', min: 45, max: 90 }]);   // item desligado não aparece
  await api('PUT', '/db/catalog/c07', { ...CAT7, items: [{ name: 'Agenda personalizada', min: 50, max: 95, on: true }, CAT7.items[1]] }, c);
  assert.deepEqual((await (await fetch(base + '/api/catalogo')).json()).categorias[1].itens[0], { nome: 'Agenda personalizada', min: 50, max: 95 });
  await api('PUT', '/db/catalog/c07', CAT7, c);
});

test('Loja: pedido de orçamento do site é conferido e chega ao painel', async () => {
  const ped = (over = {}) => ({ nome: 'Bianca Reis', telefone: '(11) 97777-1234', itens: [{ nome: 'Agenda personalizada', qtd: 2 }, { nome: 'planner personalizado', qtd: 1 }, { nome: 'Agenda personalizada', qtd: 1 }], obs: 'Capa verde\ncom nome', ...over });
  assert.equal((await fetch(base + '/api/pedido', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(ped()) })).status, 400);    // sem o cabeçalho próprio
  assert.equal((await loja('POST', '/pedido', ped(), null, { origin: 'https://outro-site.example' })).status, 403);
  assert.equal((await loja('POST', '/pedido', ped({ site: 'http://spam' }))).status, 400);
  for (const [over, campo] of [[{ nome: '' }, 'nome'], [{ telefone: '123' }, 'telefone'], [{ itens: [] }, 'itens'], [{ itens: [{ nome: 'Produto inventado', qtd: 1 }] }, 'itens'],
    [{ itens: [{ nome: 'Item desligado', qtd: 1 }] }, 'itens'], [{ itens: [{ nome: 'Agenda personalizada', qtd: 0 }] }, 'itens'], [{ itens: [{ nome: 'Agenda personalizada', qtd: 500 }] }, 'itens']]) {
    const r = await loja('POST', '/pedido', ped(over)); assert.equal(r.status, 422, JSON.stringify(over)); assert.equal((await r.json()).campo, campo); }
  const ok = await loja('POST', '/pedido', ped()); assert.equal(ok.status, 201);
  const j = await ok.json(); assert.match(j.referencia, /^S[0-9A-Z]{7}$/); assert.deepEqual(j.estimativa, { min: 180, max: 345 }); assert.equal(j.nome, 'Bianca');
  const lista = (await mcp('listar_pedidos_site', {})).data.pedidos; const p = lista.find(x => x.referencia === j.referencia); assert.ok(p);
  assert.deepEqual(p.dados.itens.map(i => [i.nome, i.qtd]), [['Agenda personalizada', 3], ['Planner personalizado', 1]]);   // nomes do catálogo, quantidades somadas
  assert.deepEqual(p.dados.cliente, { nome: 'Bianca Reis', telefone: '(11) 97777-1234', email: '' }); assert.equal(p.dados.obs, 'Capa verde com nome'); assert.equal(p.dados.clientId, null);
});

test('Loja: quem está com a conta aberta não digita os dados e vê o orçamento em "Minha conta"', async () => {
  const cad = await conta('POST', '/cadastro', novo({ email: 'loja@exemplo.com', nome: 'Renata Lima', telefone: '11 96666-0000' })); assert.equal(cad.status, 201); const ck = cookieFrom(cad);
  const ok = await loja('POST', '/pedido', { itens: [{ nome: 'Slides de formação', qtd: 1 }] }, ck); assert.equal(ok.status, 201); const ref = (await ok.json()).referencia;
  const p = (await mcp('listar_pedidos_site', {})).data.pedidos.find(x => x.referencia === ref);
  assert.equal(p.dados.cliente.nome, 'Renata Lima'); assert.equal(p.dados.cliente.email, 'loja@exemplo.com'); assert.match(p.dados.clientId, /^cli_site_/);
  let meus = (await (await conta('GET', '/pedidos', null, ck)).json()).pedidos;
  assert.deepEqual(meus.map(x => [x.numero, x.status, x.item]), [[ref, 'solicitado', 'Slides de formação']]);
  await mcp('marcar_pedido_importado', { pedido_id: p.id });   // a ESRO importou: sai da lista de orçamentos pendentes
  meus = (await (await conta('GET', '/pedidos', null, ck)).json()).pedidos; assert.equal(meus.length, 0);
  // limite de pedidos por endereço (6 por hora nos testes)
  const from = (i) => loja('POST', '/pedido', { nome: 'Teste', telefone: '11 95555-0000', itens: [{ nome: 'Agenda personalizada', qtd: 1 }] }, null, { 'cf-connecting-ip': '203.0.113.120' });
  for (let i = 0; i < 6; i++) assert.equal((await from(i)).status, 201);
  assert.equal((await from(7)).status, 429);
  await conta('POST', '/excluir', { senha: 'caderno-azul-27' }, ck);
});

test('Loja: novidades por e-mail viram contato no painel, sem duplicar', async () => {
  assert.equal((await loja('POST', '/novidades', { email: 'não é e-mail' })).status, 422);
  assert.equal((await loja('POST', '/novidades', { email: 'x@exemplo.com', site: 'x' })).status, 400);
  assert.equal((await loja('POST', '/novidades', { email: 'Ana.Clara@Exemplo.com' })).status, 200);
  assert.equal((await loja('POST', '/novidades', { email: 'ana.clara@exemplo.com' })).status, 200);
  const rows = (await pg.query(`SELECT data FROM panel_docs WHERE col='clients' AND deleted=false AND data->>'email'='ana.clara@exemplo.com'`)).rows;
  assert.equal(rows.length, 1); assert.equal(rows[0].data.origin, 'site'); assert.equal(rows[0].data.news, true); assert.equal(rows[0].data.notes.length, 1);
});

test('Monitoramento: visitas sem cookies nem IP, funil do site, atendimento e Instagram', async () => {
  assert.equal((await api('GET', '/monitor')).status, 401);
  const v = (body, extra = {}) => loja('POST', '/v', body, null, extra);
  const first = await v({ p: '/', n: true, r: 'https://www.instagram.com/esro.papelaria/' }); assert.equal(first.status, 204); assert.equal(first.headers.get('set-cookie'), null);
  await v({ p: '/', n: true, r: '' }); await v({ p: '/entrar' }); await v({ p: '/caminho-estranho' }); await v({ p: '/', e: 'carrinho' }); await v({ p: '/', e: 'evento-inventado' });
  await v({ p: '/', n: true }, { 'user-agent': 'Googlebot/2.1 (+http://www.google.com/bot.html)' });     // robô: não conta
  await v({ p: '/', n: true, r: base + '/entrar' }, { 'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/140.0 Safari/537.36' });   // veio do próprio site: conta a visita, sem origem
  await wait(); await wait();
  const m = await (await api('GET', '/monitor?dias=7', undefined, await login())).json();
  assert.equal(m.periodo.dias, 7); assert.equal(m.site.porDia.length, 7);
  assert.equal(m.site.visitas, 3); assert.equal(m.site.paginas, 5); assert.equal(m.site.porDia.at(-1).visitas, 3);
  assert.deepEqual(Object.fromEntries(m.site.origens.map(o => [o.chave, o.n])), { 'Instagram': 1, 'Direto ou link sem origem': 1 });
  assert.deepEqual(Object.fromEntries(m.site.aparelhos.map(o => [o.chave, o.n])), { Celular: 2, Computador: 1 });
  assert.deepEqual(Object.fromEntries(m.site.paginasVistas.map(o => [o.chave, o.n])), { '/': 3, '/entrar': 1, outra: 1 });
  assert.equal(m.site.eventos.carrinho, 1); assert.ok(m.site.eventos.orcamento >= 2); assert.equal(m.site.eventos.novidades, 1); assert.ok(m.site.orcamentos.recebidos >= 2);
  const stats = (await pg.query('SELECT * FROM site_stats')).rows; assert.ok(stats.every(r => Object.keys(r).join() === 'day,kind,key,n'));   // só contagens
  // Instagram: perfil, publicações (link inseguro é descartado) e retrato do dia; sem permissão de alcance o resto funciona
  assert.equal(m.instagram.configurado, true); assert.deepEqual(m.instagram.perfil, { usuario: 'esro.papelaria', nome: 'ESRO', seguidores: 321, seguindo: 100, publicacoes: 18 });
  assert.deepEqual(m.instagram.posts.map(p => [p.tipo, p.curtidas, p.comentarios, p.link]), [['Foto', 42, 5, 'https://www.instagram.com/p/abc/'], ['Reels', 7, 0, null]]);
  assert.equal(m.instagram.posts[0].legenda, 'Agenda 2027 com nome na capa'); assert.equal(m.instagram.ultimos28dias, null);
  assert.deepEqual(m.instagram.seguidoresPorDia.map(x => x.seguidores), [321]);
  assert.ok(!JSON.stringify(m).includes('ig-token'));
  // Atendimento: mensagens por dia e tempo de resposta saem do que os webhooks gravaram
  assert.ok(m.atendimento.conversas >= 1); assert.equal(m.atendimento.porDia.length, 7); assert.equal(typeof m.atendimento.naoLidas, 'number');
});

test('Loja: preço por quantidade e variações vêm do painel e são conferidos no servidor', async () => {
  const c = await login(), site = (m, p, b) => fetch(base + '/api' + p, { method: m, headers: H, body: b ? JSON.stringify(b) : undefined });
  await api('PUT', '/db/products/prd_bloco_teste', { name: 'Bloco de teste', mode: 'compra', price: 18, on: true, tiers: [{ min: 10, price: 15 }, { min: 50, price: 13 }],
    vars: [{ nome: 'Capa', ops: [{ n: 'Simples', add: 0 }, { n: 'Dura', add: 17 }] }], pers: '' }, c);
  const p = (await (await site('GET', '/produtos/bloco-de-teste')).json()).produto; assert.deepEqual(p.faixasQtd, [{ min: 10, preco: 15 }, { min: 50, preco: 13 }]);
  const sub = async (q, capa) => (await (await site('POST', '/frete', { itens: [{ id: 'prd_bloco_teste', qtd: q, vars: { Capa: capa } }] })).json()).subtotal;
  assert.deepEqual([await sub(9, 'Simples'), await sub(10, 'Simples'), await sub(12, 'Simples'), await sub(10, 'Dura'), await sub(50, 'Simples'), await sub(60, 'Dura')], [162, 150, 180, 320, 650, 1800]);
  assert.equal((await site('POST', '/frete', { itens: [{ id: 'prd_bloco_teste', qtd: 3, vars: { Capa: 'Ouro' } }] })).status, 422);
  await api('DELETE', '/db/products/prd_bloco_teste', undefined, c);
});

test('Depoimentos: o cliente escreve pela conta só em pedido próprio e enviado; o painel sugere elogios do Instagram', async () => {
  const ip = { 'cf-connecting-ip': '198.51.100.31' };
  const cad = await conta('POST', '/cadastro', novo({ email: 'depo@exemplo.com', telefone: '11 97777-1234' }), null, ip); assert.equal(cad.status, 201);
  const cookie = cookieFrom(cad);
  const row = (await pg.query(`SELECT * FROM site_users WHERE email = 'depo@exemplo.com'`)).rows[0];
  const adm = await login();
  await api('PUT', '/db/orders/pd1', { num: 2101, at: '2026-10-05T12:00:00.000Z', client: 'Marina Souza', clientId: row.client_id, item: 'Caderno personalizado', value: 42, status: 'concluido' }, adm);
  await api('PUT', '/db/orders/pd2', { num: 2102, at: '2026-10-06T12:00:00.000Z', client: 'Marina Souza', clientId: row.client_id, item: 'Agenda', value: 59.9, status: 'producao' }, adm);
  await api('PUT', '/db/orders/pd3', { num: 2103, at: '2026-10-06T12:00:00.000Z', client: 'Outra', clientId: 'cli_outra', item: 'Agenda', value: 59.9, status: 'concluido' }, adm);
  const situ = async () => Object.fromEntries((await (await conta('GET', '/pedidos', null, cookie)).json()).pedidos.map(p => [p.numero, p.depoimento]));
  let s = await situ(); assert.equal(s[2101], 'pode'); assert.equal(s[2102], null);
  const dep = { numero: 2101, nome: 'Marina S.', cidade: 'Osasco', texto: 'O caderno ficou perfeito, a minha filha amou o nome na capa.', aceite: true };
  assert.equal((await conta('POST', '/depoimentos', dep)).status, 401);                                     // sem login
  assert.equal((await conta('POST', '/depoimentos', { ...dep, numero: 2103 }, cookie)).status, 404);        // pedido de outra pessoa
  assert.equal((await conta('POST', '/depoimentos', { ...dep, numero: 2102 }, cookie)).status, 409);        // ainda em produção
  assert.equal((await conta('POST', '/depoimentos', { ...dep, aceite: false }, cookie)).status, 422);
  assert.equal((await conta('POST', '/depoimentos', dep, cookie)).status, 201);
  assert.equal((await conta('POST', '/depoimentos', dep, cookie)).status, 409);
  const d = (await pg.query(`SELECT data FROM panel_docs WHERE col = 'depoimentos' AND id = 'dep_pd1'`)).rows[0].data;
  assert.deepEqual([d.status, d.origem, d.verificado, d.autorizado, d.pedido, d.clientId], ['pendente', 'conta', true, true, 2101, row.client_id]);
  s = await situ(); assert.equal(s[2101], 'em revisão');
  await api('PATCH', '/db/depoimentos/dep_pd1', { status: 'aprovado' }, adm);
  s = await situ(); assert.equal(s[2101], 'publicado');
  const pub = (await (await fetch(base + '/api/depoimentos')).json()).depoimentos.find(x => x.nome === 'Marina S.');
  assert.equal(pub.origem, 'Pelo site'); assert.equal(pub.verificado, true);

  // Instagram: só elogios, sem perguntas, reclamações ou comentários da própria ESRO
  assert.equal((await fetch(base + '/painel/api/depoimentos/instagram', { headers: H })).status, 401);
  let ig = await (await api('GET', '/depoimentos/instagram?atualizar=1', undefined, adm)).json();
  assert.equal(ig.configurado, true); assert.equal(ig.erro, null);
  assert.deepEqual(ig.comentarios.map(c => c.id).sort(), ['c1', 'c5']);
  assert.equal(ig.comentarios.find(c => c.id === 'c1').post, 'https://www.instagram.com/p/abc/');
  // Comentário que chega pelo aviso automático (webhook assinado) também entra
  const wh = JSON.stringify({ object: 'instagram', entry: [{ id: '1', time: 1, changes: [{ field: 'comments', value: { id: 'c9', text: 'Lindo demais, recomendo!', from: { id: '9', username: 'leticia' }, media: { id: 'm1' } } }] }] });
  assert.equal((await fetch(base + '/webhooks/instagram', { method: 'POST', headers: { 'content-type': 'application/json', 'x-hub-signature-256': sign('ig-secret', wh) }, body: wh })).status, 200);
  await new Promise(r => setTimeout(r, 80));
  ig = await (await api('GET', '/depoimentos/instagram', undefined, adm)).json();
  assert.ok(ig.comentarios.some(c => c.id === 'c9' && c.usuario === 'leticia'));
  // Ignorar e usar como depoimento tiram o comentário da lista
  assert.equal((await api('POST', '/depoimentos/instagram/c5/ignorar', {}, adm)).status, 200);
  await api('PUT', '/db/depoimentos/ig1', { nome: 'Ana', texto: 'Amei a agenda, ficou linda demais! 😍', origem: 'instagram', igComentario: 'c1', autorizado: true, status: 'aprovado', at: '2026-10-07T12:00:00.000Z' }, adm);
  ig = await (await api('GET', '/depoimentos/instagram', undefined, adm)).json();
  assert.deepEqual(ig.comentarios.map(c => c.id), ['c9']);
  assert.equal((await api('POST', '/depoimentos/instagram/x%20y/ignorar', {}, adm)).status, 422);
});
